import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TraineeGraphComponent } from './trainee-graph.component';

describe('TraineeGraphComponent', () => {
  let component: TraineeGraphComponent;
  let fixture: ComponentFixture<TraineeGraphComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TraineeGraphComponent]
    });
    fixture = TestBed.createComponent(TraineeGraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
