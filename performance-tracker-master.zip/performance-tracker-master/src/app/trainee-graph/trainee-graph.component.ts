import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import { TraineegraphService } from './traineegraph.service';
import { ActivatedRoute } from '@angular/router';

import { Options } from 'highcharts';
@Component({
  selector: 'app-trainee-graph',
  templateUrl: './trainee-graph.component.html',
  styleUrls: ['./trainee-graph.component.css']
})
export class TraineeGraphComponent implements OnInit{

  id!:number;
  zid!:string;

  myMarks:any=[];
  scores: number[] =[];
  retestno:string[]=[];
  
  
  public Highcharts: typeof Highcharts = Highcharts; // Required
  
  chartOptions: Highcharts.Options = {
    title: {
      text: 'My Mark'
    },
  
    xAxis: {
      categories: []
  },
    series: [{
      type: 'line',
      name: 'mark',
      data: [],
      
    }] 
  }

  constructor(private traineegraphService : TraineegraphService,private route:ActivatedRoute)
  {
    
  }

  

  ngOnInit()
  {
   this.id =  this.route.snapshot.params['id'];
    this.zid = this.route.snapshot.params['zid'];
    
    this.traineegraphService.getScoreByTopicId(this.id,this.zid).subscribe(data=>{
        // console.log(data);
        this.arr2(data);
        // console.log(this.myMarks);

        // this.chartOptions.xAxis.categories[0] = this.retestno;

        if(this.chartOptions.series === undefined)
        {
          this.chartOptions.series = [];
        }

        this.chartOptions.series[0] = {

          type: 'line',
          name: 'mark',
          data: this.scores
        };
        this.updateChart();
    });

    
  }

  updateChart()
  {
    this.Highcharts.charts[0]?.update(this.chartOptions,true);
  }


  arr2(arr: any)
  {
      arr.forEach((v:any)=>{
        var items:any={};
          let key = "retestno";
          let value = v[0];
          
          items[key] = value;

          key="score"
          value = v[1];

          items[key] = value;


          key="result"
          value = v[2];

          items[key] = value;

          //finally adding score only to separate array
          this.scores.push(v[1]);  

          //pushing every single object into array
          this.myMarks.push(items);

          //also adding retestno only separare array
          this.retestno.push("Retest-"+v[0]);

      })
  }




}
