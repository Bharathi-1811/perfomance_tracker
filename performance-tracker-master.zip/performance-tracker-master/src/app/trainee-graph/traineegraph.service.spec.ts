import { TestBed } from '@angular/core/testing';

import { TraineegraphService } from './traineegraph.service';

describe('TraineegraphService', () => {
  let service: TraineegraphService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TraineegraphService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
