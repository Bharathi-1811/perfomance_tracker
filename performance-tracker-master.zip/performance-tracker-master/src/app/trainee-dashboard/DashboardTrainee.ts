export class DashboardTrainee{
    name!:string; 
}