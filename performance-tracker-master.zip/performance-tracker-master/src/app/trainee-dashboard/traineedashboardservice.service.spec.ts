import { TestBed } from '@angular/core/testing';

import { TraineedashboardserviceService } from './traineedashboardservice.service';

describe('TraineedashboardserviceService', () => {
  let service: TraineedashboardserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TraineedashboardserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
