import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DashboardTrainee } from './DashboardTrainee';

@Injectable({
  providedIn: 'root'
})
export class TraineedashboardserviceService {

  constructor(private http:HttpClient) { }

  private baseURL="http://localhost:8090/api/v1/batchtraineecombination";

  getDashboardTrainee(id:string):Observable<Object>
  {
    return this.http.get(`${this.baseURL}`+`/getdashboardbatch/${id}`);
  }
  

}
