import { Component, Input } from '@angular/core';
import { TraineedashboardserviceService } from './traineedashboardservice.service';
import { DashboardTrainee } from './DashboardTrainee';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trainee-dashboard',
  templateUrl: './trainee-dashboard.component.html',
  styleUrls: ['./trainee-dashboard.component.css']
})
export class TraineeDashboardComponent {

  myBatches:any=[];
  zid:string="z041413";
  
  constructor(private traineeDashboard : TraineedashboardserviceService, private router:Router) { }

  
  ngOnInit()
  {
    this.traineeDashboard.getDashboardTrainee(this.zid).subscribe(data=>{
        
      console.log(data);
      //converting array of arrays into objects
        this.arr2(data); 
        console.log(this.myBatches);
    });

  }

  
  arr2(arr: any)
  {
      arr.forEach((v:any)=>{
        var items:any={};
          let key = "name";
          let value = v[3];
          
          items[key] = value;

          key="batchId"
          value = v[0];

          items[key] = value;

          this.myBatches.push(items);
      })
  }

  topicview(id:number){
    this.router.navigate(['traineetopic', id,this.zid]);
  }

  

/* sample static batches array*/

// public batches = [

//   {name:"Java"},

//   {name:"C#"},

//   {name:"Angular"},

//   {name:"Javascript"},

//   {name:"TypeScript"},

//   ];

}
