import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Result } from '../admin/result/result-view/result';
import { ResultService } from '../admin/result/result.service';





@Component({
  selector: 'app-trainee-result',
  templateUrl: './trainee-result.component.html',
  styleUrls: ['./trainee-result.component.css']
})
export class TraineeResultComponent {


  // result!:Result[];
  // id!:number;
  // constructor(private resultService:ResultService,private router:Router)
  // {

  // }

  // ngOnInit():void
  // {
    
  // }


}
