import { Component, HostBinding, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trainee-topnavbar',
  templateUrl: './trainee-topnavbar.component.html',
  styleUrls: ['./trainee-topnavbar.component.css']
})

export class TraineeTopnavbarComponent {

  constructor(private router: Router)
  {

  }

  public data =["Profile"];
  public value:string="";


  setElement($event: string)
  {
    this.value = $event;
    if(this.value == "Profile")
    {
        this.router.navigate(["/profile"])
    }
    console.log(this.value)
    
  }

  toggleControl = new FormControl(false);

  @Input() collapsed = false;
  @Input() screenWidth = 0;

  getNavbar(): string {
    let styleClass = '';
    if (this.collapsed && this.screenWidth > 768) {
      styleClass = 'nav-trimmed';
    }
    else if (this.collapsed && this.screenWidth <= 768 && this.screenWidth > 0) {
      styleClass = 'nav-md-screen';
    }
    return styleClass;

  }




//  @HostBinding('class') className = '';
//   darkClassName = 'dark';
//   lightClassName = 'light';
//   overlay: any;

//   ngOnInit() {

//     this.toggleControl.valueChanges.subscribe((darkMode) => {
//       this.className = darkMode ? this.darkClassName : this.lightClassName;
//       if (darkMode) {
//         this.overlay.getContainerElement().classList.add(this.darkClassName);
//       }
//       else {
//         this.overlay.getContainerElement().classList.add(this.darkClassName);
//       }
//     })


// }
}
