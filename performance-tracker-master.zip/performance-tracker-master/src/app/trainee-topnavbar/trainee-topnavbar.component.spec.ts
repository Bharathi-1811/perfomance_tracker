import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TraineeTopnavbarComponent } from './trainee-topnavbar.component';

describe('TraineeTopnavbarComponent', () => {
  let component: TraineeTopnavbarComponent;
  let fixture: ComponentFixture<TraineeTopnavbarComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TraineeTopnavbarComponent]
    });
    fixture = TestBed.createComponent(TraineeTopnavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
