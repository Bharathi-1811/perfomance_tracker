import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  private userProfile = {
    name: ' ',
    email: ' ',
    Zid:' ',
    Phone:'',
    Gender:'',
  };

  getUserProfile(): any {
    return this.userProfile;
  }

  updateUserProfile(updatedProfile: any): void {
    this.userProfile = updatedProfile;
  }
}
