import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../profile.service';

@Component({
  selector: 'app-viewprofile',
  templateUrl: './viewprofile.component.html',
  styleUrls: ['./viewprofile.component.css']
})
export class ViewprofileComponent implements OnInit {

  userProfile: any; 

  constructor(private profileService: ProfileService) {}

  ngOnInit(): void {
    this.userProfile = this.profileService.getUserProfile();
  }

}
