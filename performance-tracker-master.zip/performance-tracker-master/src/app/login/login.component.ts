import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { checkZidValidation, noSpaceAllowed } from '../restricted.directive';
import { LoginserviceService } from './loginservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  constructor(private router:Router,private loginService:LoginserviceService)
  {

  }

  value:any={};
  error!:string;

  zidpattern = "^[Zz]{1}[0-9]{6}$";

  passwordpattern = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,16}$";
  


  loginForm = new FormGroup({
    zid: new FormControl('',[Validators.required,Validators.minLength(7),Validators.maxLength(7),noSpaceAllowed(),Validators.pattern(this.zidpattern)]),
    password: new FormControl('',[Validators.required,Validators.minLength(8),Validators.maxLength(15),noSpaceAllowed(),Validators.pattern(this.passwordpattern)])
  });

  login()
  {
    this.value = this.loginForm.value;
    
   this.loginService.checkLogin(this.value).subscribe(data=>{
      console.log(data);
      this.error = data;
    });
    
  }

  get zid()
  {
    return this.loginForm.get('zid');
  }
  get password()
  {
    return this.loginForm.get('password');
  }




}
