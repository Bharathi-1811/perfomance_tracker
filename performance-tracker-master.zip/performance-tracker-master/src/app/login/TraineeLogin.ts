export class TraineeLogin
{
    zid!:string;
    password!:string;
}