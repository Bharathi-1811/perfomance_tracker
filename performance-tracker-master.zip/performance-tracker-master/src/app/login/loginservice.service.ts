import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TraineeLogin } from './TraineeLogin';

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {

  constructor(private http:HttpClient) { }

  private baseURL="http://localhost:8090/trainee/checklogin";

  checkLogin(data:TraineeLogin):Observable<any>
  {
    return this.http.post(`${this.baseURL}`,data);
  }

}
