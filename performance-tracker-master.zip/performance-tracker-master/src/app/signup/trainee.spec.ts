import { Trainee } from './trainee';

describe('Trainee', () => {
  it('should create an instance', () => {
    expect(new Trainee()).toBeTruthy();
  });
});
