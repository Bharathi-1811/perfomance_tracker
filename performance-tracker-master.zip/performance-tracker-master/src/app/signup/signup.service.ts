import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Trainee } from './trainee';

@Injectable({
  providedIn: 'root'
})
export class SignupService {

  
  private baseURL="http://localhost:8090/traineesignup";


  constructor(private http:HttpClient) { }

  updateTrainee(id:number,trainee:Trainee):Observable<object>
  {
    return this.http.put(`${this.baseURL}`+`/update/${id}`,trainee)
  }


}
