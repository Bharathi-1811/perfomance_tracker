import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SignupService } from './signup.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {

  zid!:number;
  signData:any={};

  ngOnInit():void
  {
    this.zid = this.route.snapshot.params['zid'];
  }

  constructor(private router:Router,private signUpService:SignupService,private route:ActivatedRoute)
  {
   
  }

  signForm = new FormGroup({
    name:new FormControl('',[]),
    mobileNumber:new FormControl('',[]),
    password:new FormControl('',[]),
    confirmPassword:new FormControl('',[]),
    gender:new FormControl('',[]),
  });

  signup()
  {
    this.signData = this.signForm.value;
    
    this.signUpService.updateTrainee(this.zid,this.signData).subscribe(data=>{
      console.log(data);
    });
  }

  

}
