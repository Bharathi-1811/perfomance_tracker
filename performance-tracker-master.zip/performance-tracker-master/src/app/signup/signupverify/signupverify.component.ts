import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SignupService } from '../signup.service';

@Component({
  selector: 'app-signupverify',
  templateUrl: './signupverify.component.html',
  styleUrls: ['./signupverify.component.css']
})
export class SignupverifyComponent {

  token!:string;
  // ngOnInit():void
  // {
  //   this.token = this.route.snapshot.params['token'];
  //   this.signUpService
  // }

  // constructor(private router:Router,private signUpService:SignupService,private route:ActivatedRoute)
  // {
    
  // }



}
