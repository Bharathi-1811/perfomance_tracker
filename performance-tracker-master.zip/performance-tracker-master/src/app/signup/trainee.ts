export class Trainee {
    name!:string;
    mobileNumber!:string;
    password!:string;
    gender!:string;
}
