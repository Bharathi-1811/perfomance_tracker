import { Upcomingtest } from './upcomingtest';

describe('Upcomingtest', () => {
  it('should create an instance', () => {
    expect(new Upcomingtest()).toBeTruthy();
  });
});
