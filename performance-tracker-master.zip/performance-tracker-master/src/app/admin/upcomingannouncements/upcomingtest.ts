export class Upcomingtest {
    testId!:number;
    combinationId!:number;
    retestNo!:number;
    selectDate!:number;
}
