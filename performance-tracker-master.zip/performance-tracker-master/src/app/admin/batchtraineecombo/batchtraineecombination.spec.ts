import { Batchtraineecombination } from './batchtraineecombination';

describe('Batchtraineecombination', () => {
  it('should create an instance', () => {
    expect(new Batchtraineecombination()).toBeTruthy();
  });
});
