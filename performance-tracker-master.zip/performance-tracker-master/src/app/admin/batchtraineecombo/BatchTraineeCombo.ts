export class BatchTraineeCombo
{
    id !:number;
    zid !:string;
    name !:string;
}