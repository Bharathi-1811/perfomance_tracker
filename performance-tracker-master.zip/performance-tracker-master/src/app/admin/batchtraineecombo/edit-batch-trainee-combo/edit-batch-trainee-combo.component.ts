import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-batch-trainee-combo',
  templateUrl: './edit-batch-trainee-combo.component.html',
  styleUrls: ['./edit-batch-trainee-combo.component.css']
})
export class EditBatchTraineeComboComponent {

}
