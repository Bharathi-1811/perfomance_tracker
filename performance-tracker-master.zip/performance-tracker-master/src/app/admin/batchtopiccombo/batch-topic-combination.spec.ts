import { BatchTopicCombination } from './batch-topic-combination';

describe('BatchTopicCombination', () => {
  it('should create an instance', () => {
    expect(new BatchTopicCombination()).toBeTruthy();
  });
});
