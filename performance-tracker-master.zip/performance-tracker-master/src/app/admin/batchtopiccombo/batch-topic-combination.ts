export class BatchTopicCombination {
    batchTopicId!:number;
    batchId!:number;
    topicId!:number;
}
