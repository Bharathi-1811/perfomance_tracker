export class Topic {
    topicId!:number;
    topicName!:string;
}
