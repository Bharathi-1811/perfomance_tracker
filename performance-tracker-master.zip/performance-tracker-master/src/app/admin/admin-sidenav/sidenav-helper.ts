export interface AdminNavbarData
{
    routeLink:string;
    icon?:string;
    label:string;
    expanded?:string;
    items?:AdminNavbarData[];
}