export class Addtrainee {
    
    id!:number;
    zid !:number;
    email !:any;
    isSelected !: boolean;
    status!:string;
}
