import { Addtrainee } from './addtrainee';

describe('Addtrainee', () => {
  it('should create an instance', () => {
    expect(new Addtrainee()).toBeTruthy();
  });
});
