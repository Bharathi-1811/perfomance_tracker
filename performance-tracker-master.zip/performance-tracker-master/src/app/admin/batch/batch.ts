export class Batch {
    batchId!: number;
    year!: String ;
    name!: String;
}
