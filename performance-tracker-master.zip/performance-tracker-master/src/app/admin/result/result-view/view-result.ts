export class ViewResult {

    name!:string;
    value!:number;
    colorValue!:number;
}
