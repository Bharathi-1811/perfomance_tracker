export class Result {

    rid!:number;
    zid!:string;
    score!:number;
    result!:string;
}
