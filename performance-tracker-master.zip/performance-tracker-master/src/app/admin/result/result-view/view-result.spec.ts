import { ViewResult } from './view-result';

describe('ViewResult', () => {
  it('should create an instance', () => {
    expect(new ViewResult()).toBeTruthy();
  });
});
