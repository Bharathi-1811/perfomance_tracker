import { Result } from './result-view/result';

describe('Result', () => {
  it('should create an instance', () => {
    expect(new Result()).toBeTruthy();
  });
});
