import { ResultPipe } from './result.pipe';

describe('ResultPipe', () => {
  it('create an instance', () => {
    const pipe = new ResultPipe();
    expect(pipe).toBeTruthy();
  });
});
