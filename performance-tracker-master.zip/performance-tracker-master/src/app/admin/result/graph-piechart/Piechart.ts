export class Piechart{
    passed !: number;
    failed!: number
}