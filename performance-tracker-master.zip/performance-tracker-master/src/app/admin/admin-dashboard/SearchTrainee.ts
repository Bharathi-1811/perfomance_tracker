export class SearchTrainee {
  
    id !:number;
    zid !:number;
    name!:string;

}