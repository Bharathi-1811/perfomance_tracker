import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TraineeBodyComponent } from './trainee-body.component';

describe('TraineeBodyComponent', () => {
  let component: TraineeBodyComponent;
  let fixture: ComponentFixture<TraineeBodyComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TraineeBodyComponent]
    });
    fixture = TestBed.createComponent(TraineeBodyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
