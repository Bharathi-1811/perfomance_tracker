import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TraineeSidenavComponent } from './trainee-sidenav.component';

describe('TraineeSidenavComponent', () => {
  let component: TraineeSidenavComponent;
  let fixture: ComponentFixture<TraineeSidenavComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TraineeSidenavComponent]
    });
    fixture = TestBed.createComponent(TraineeSidenavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
