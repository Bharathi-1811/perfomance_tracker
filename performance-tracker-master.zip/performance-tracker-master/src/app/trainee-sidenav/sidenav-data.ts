export const navbarData = [
    {
        routeLink: 'dashboard',
        icon: 'bi bi-calendar2',
        label: 'Dashboard'
    },
    {
        routeLink: 'announce',
        icon: "bi bi-megaphone",
        label: 'Announcements'

    },
    {
        routeLink: 'result',
        icon: 'bi bi-clipboard2-data',
        label: 'Results'

    },

];