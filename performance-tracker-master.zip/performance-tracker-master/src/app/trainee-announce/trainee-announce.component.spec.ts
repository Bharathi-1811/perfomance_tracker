import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TraineeAnnounceComponent } from './trainee-announce.component';

describe('TraineeAnnounceComponent', () => {
  let component: TraineeAnnounceComponent;
  let fixture: ComponentFixture<TraineeAnnounceComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TraineeAnnounceComponent]
    });
    fixture = TestBed.createComponent(TraineeAnnounceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
