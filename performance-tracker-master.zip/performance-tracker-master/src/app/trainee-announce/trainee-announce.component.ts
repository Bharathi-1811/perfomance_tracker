import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { UpcomingService } from '../admin/upcomingannouncements/upcoming.service';
import { Upcomingtest } from '../admin/upcomingannouncements/upcomingtest';

@Component({
  selector: 'app-trainee-announce',
  templateUrl: './trainee-announce.component.html',
  styleUrls: ['./trainee-announce.component.css']
})
export class TraineeAnnounceComponent {


  tracs!: Upcomingtest[];

  constructor(private perservice: UpcomingService, private router: Router) {

  }
  ngOnInit(): void {
    this.getAllcom();
  }
  private getAllcom() {
    this.perservice.getcomAll().subscribe(data => {
      this.tracs = data;
      console.log(this.tracs);
    });

  }


}
