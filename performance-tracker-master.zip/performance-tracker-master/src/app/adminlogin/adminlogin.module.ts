import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminloginComponent } from './adminlogin.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AdminloginComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    AdminloginComponent,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class AdminloginModule { }
