import { TestBed } from '@angular/core/testing';

import { AdminTraineeViewService } from './admin-trainee-view.service';

describe('AdminTraineeViewService', () => {
  let service: AdminTraineeViewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminTraineeViewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
