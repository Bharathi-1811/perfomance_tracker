import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTraineeViewComponent } from './admin-trainee-view.component';

describe('AdminTraineeViewComponent', () => {
  let component: AdminTraineeViewComponent;
  let fixture: ComponentFixture<AdminTraineeViewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminTraineeViewComponent]
    });
    fixture = TestBed.createComponent(AdminTraineeViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
