import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AdminTraineeViewService } from './admin-trainee-view.service';

@Component({
  selector: 'app-admin-trainee-view',
  templateUrl: './admin-trainee-view.component.html',
  styleUrls: ['./admin-trainee-view.component.css']
})
export class AdminTraineeViewComponent {

  zid!:string;
  myData:any=[];

  constructor(private route:ActivatedRoute,private adminTraineeView:AdminTraineeViewService)
  {
    
  }

  //sample data to check frontend
  // subjects = [
  //   { name: 'Java', attempts: 3, marks: 90 },
  //   { name: 'Angular', attempts: 2, marks: 85 },
  //   { name: 'Spring', attempts: 4, marks: 78 },
  //   { name: 'Advance Java', attempts: 1, marks: 92 },
  //   { name: 'Java', attempts: 3, marks: 90 },
  //   { name: 'Angular', attempts: 2, marks: 85 },
  //   { name: 'Spring', attempts: 4, marks: 78 },
  //   { name: 'Advance Java', attempts: 1, marks: 92 },
  //   { name: 'Java', attempts: 3, marks: 90 },
  //   { name: 'Angular', attempts: 2, marks: 85 },
  //   { name: 'Spring', attempts: 4, marks: 78 },
  //   { name: 'Advance Java', attempts: 1, marks: 92 },

    
  // ];

  ngOnInit()
  {
    this.zid = this.route.snapshot.params['value'];
   
    this.adminTraineeView.getSingleTraineeDetails(this.zid).subscribe(data=>{
        console.log(data);
        this.convertIntoObjects(data);
        console.log(this.myData);
    });

  }

  convertIntoObjects(arr:any)
  {
    arr.forEach((v:any)=>{
      var items:any={};
        let key = "result";
        let value = v[0];
        items[key] = value;

        key = "score";
        value = v[1];
        items[key] = value;

        key="retestno"
        value=v[4];
        items[key] = value;

        key="batchname"
        value=v[5];
        items[key] = value;

        key="topicname";
        value=v[6];
        items[key] = value;

        this.myData.push(items);
    })
  }

}
