import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent {

  oldPassword: string = '';
  password: string = '';
  confirmPassword: string = '';

  submitPasswordForm() {
    if (this.password === this.confirmPassword) {
      if (this.oldPassword === 'your_old_password') {
        // Old password matches, and new passwords match. You can now handle the password change logic here.
        // For demonstration purposes, we'll simply log a success message.
        console.log('Password change successful');
      } else {
        console.log('Old password is incorrect');
      }
    } else {
      console.log('New passwords do not match');
    }
  }

  validatePasswordsMatch(passwordForm: NgForm) {
    if (passwordForm.value.password !== passwordForm.value.confirmPassword) {
      passwordForm.control.setErrors({ passwordsNotMatch: true });
    } else {
      passwordForm.control.setErrors(null);
    }
  }
}



