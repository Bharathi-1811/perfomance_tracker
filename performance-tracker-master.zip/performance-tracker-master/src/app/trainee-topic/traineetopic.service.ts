import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TraineetopicService {
  constructor(private http:HttpClient) { }

  private baseURL="http://localhost:8090/api/v1/batchtopiccombination";

  getDashboardTopic(id:number):Observable<Object>
  {
    return this.http.get(`${this.baseURL}`+`/dashboard/${id}`);
  }
 
}
