import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TraineetopicService } from './traineetopic.service';

@Component({
  selector: 'app-trainee-topic',
  templateUrl: './trainee-topic.component.html',
  styleUrls: ['./trainee-topic.component.css']
})
export class TraineeTopicComponent {

  
  myTopics:any=[];
  id!:number;
  zid!:string;
  
  constructor(private traineeTopic : TraineetopicService, private router:Router, private route: ActivatedRoute) { }

  
  ngOnInit()
  {
    this.id = this.route.snapshot.params['id'];
    this.zid = this.route.snapshot.params['zid'];
    this.traineeTopic.getDashboardTopic(this.id).subscribe(data=>{
      console.log(data);
      //converting array of arrays into objects
        this.arr2(data); 
        console.log(this.myTopics);
    });

  }

  
  arr2(arr: any)
  {
      arr.forEach((v:any)=>{
        var items:any={};
          let key = "topicId";
          let value = v[0];
          
          items[key] = value;

          key="topicName"
          value = v[1];

          items[key] = value;

          this.myTopics.push(items);
      })
  }

  linechart(id:number){
    this.router.navigate(['traineegraph', id, this.zid]);
  }


}
