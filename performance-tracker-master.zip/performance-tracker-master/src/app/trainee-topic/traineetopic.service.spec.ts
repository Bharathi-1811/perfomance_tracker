import { TestBed } from '@angular/core/testing';

import { TraineetopicService } from './traineetopic.service';

describe('TraineetopicService', () => {
  let service: TraineetopicService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TraineetopicService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
