import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TraineeTopicComponent } from './trainee-topic.component';

describe('TraineeTopicComponent', () => {
  let component: TraineeTopicComponent;
  let fixture: ComponentFixture<TraineeTopicComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TraineeTopicComponent]
    });
    fixture = TestBed.createComponent(TraineeTopicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
